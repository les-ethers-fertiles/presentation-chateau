---
title: "Venez converser avec nous"
description: "les accompagnateurs-enseignants de C'est Le Bouquet sont disponibles sur..."
slug: "venez-converser-avec-nous"
image: converser.jpg
keywords: ""
categories:
    - ""
    - ""
date: 2017-10-31T22:26:13-05:00
draft: false
---

Les accompagnateurs-enseignants sont disponibles en ligne sur le chat de l'association, la mailing list, et tous les vendredis en tête à tête de 12h à15h à La Mezzanine au 20 rue Tourat pour y partager leurs productions, ressources pédagogiques, méthodologies et pratiques du travail coopératif (dont ce qu'on appelle "le mode de production pair-à-pair").

