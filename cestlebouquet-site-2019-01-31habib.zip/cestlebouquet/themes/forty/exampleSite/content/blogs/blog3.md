---
title: "Tempus"
description: "Nullam et orci eu lorem consequat tincidunt vivamus et sagittis magna sed nunc rhoncus condimentum sem. In efficitur ligula tate urna. Maecenas massa sed magna lacinia magna pellentesque lorem ipsum dolor. Nullam et orci eu lorem consequat tincidunt. Vivamus et sagittis tempus."
slug: "tempus"
image: pic08.jpg
keywords: ""
categories: 
    - ""
    - ""
date: 2017-10-31T22:26:13-05:00
draft: false
---
