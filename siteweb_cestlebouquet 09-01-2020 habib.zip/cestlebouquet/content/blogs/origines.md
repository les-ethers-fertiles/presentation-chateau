---
title: "Aux origines de la plateforme"
description: "Émanation du Fournisseur d'Accès Internet associatif Aquilenet, C'est le Bouquet est un réseau d'accompagnateurs et de techniciens basés en Nouvelle Aquitaine..."
image: origines.jpg
keywords: ""
categories:
    - ""
    - ""
date: 2017-10-31T21:28:43-05:00
draft: false
---

C'est une émanation du Fournisseur d'Accès Internet associatif aquitain [Aquilenet](aquilenet.fr), qui vous permet d'explorer Internet en étant accompagné d'une communauté de pairs passionnés, prêts à vous aider à comprendre ce que vous y faites, à vous conseiller sur vos choix techniques, à apprendre avec vous.


