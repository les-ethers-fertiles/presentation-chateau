---
title: "Nous rencontrer, Travailler ensemble"
description: "Disponibles tout au long de la semaine, en ligne ou (encore mieux) sur place dans la métropole Bordelaise pour échanger sur des outils, méthodologies, bonnes pratiques..."
image: converser.jpg
keywords: ""
categories:
    - ""
    - ""
date: 2017-10-31T22:26:13-05:00
draft: false
---

Les accompagnateurs sont disponibles pour y partager leurs productions, ressources pédagogiques, méthodologies et pratiques du production de pair-à-pair:<br>
- en présentiel à La Mezzanine **au 20 rue Tourat** (le mardi soir de 18h à 22h);<br>
- en **déplacement sur demande** en écrivant à *accompagnement@cestlebouquet.fr* (7 jours sur 7);<br>
- en ligne sur la **mailing list** *cestlebouquet@listes.aquilenet.fr* (7 jours sur 7);<br>
- en ligne par **messagerie instantanée** sur l' *IRC #cestlebouquet*  (7 jours sur 7);<br>