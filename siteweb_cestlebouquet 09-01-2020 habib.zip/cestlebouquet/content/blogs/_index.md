---
title: "Nous lire"
slug: "blogs"
image: banner.jpg
date: 2017-10-31T22:27:21-05:00
draft: false
---

Choisir ses logiciels de travail en commun, voire même en changer, n'est pas un acte anodin. Tel un artisan qui choisit ses outils méticuleusement pour pouvoir faire les plus beaux gestes lors de ses créations, de nombreux questionnements se soulèvent pour bien saisir le pourquoi, le comment, le qui...Sur ce blog, nous écrivons sur cela:
